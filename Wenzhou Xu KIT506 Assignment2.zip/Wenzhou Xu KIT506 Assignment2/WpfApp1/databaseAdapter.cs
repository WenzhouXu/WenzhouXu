﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MySql.Data.MySqlClient;
using MySql.Data.Types;

namespace RAP_App
{
    class databaseAdapter
    {
     //These would not be hard coded in the source file normally, but read from the application's settings (and, ideally, with some amount of basic encryption applied)
     private const string db = "kit206";
     private const string user = "kit206";
     private const string pass = "kit206";
     private const string server = "alacritas.cis.utas.edu.au";

     private static MySqlConnection conn = null;

    public static T ParseEnum<T>(string value)
    {
        return (T)Enum.Parse(typeof(T), value);
    }


        /// <summary>
        /// Creates and returns (but does not open) the connection to the database.
        /// <summary>
        private static MySqlConnection GetConnection()
        {
            if (conn == null)
            {
                //Note: This approach is not thread-safe
                string connectionString = String.Format("Database={0};Data Source={1};User Id={2};Password={3}", db, server, user, pass);
                conn = new MySqlConnection(connectionString);
            }
            return conn;

        }

        //For 2.2 step  in RAP App
        public static List<Position> LoadAll()
        {
            List<Position> Position = new List<>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("id,level, start,end", conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    //Note that inthis RAP assignment you will need to inspect the *type* of the
                    //staff/researcher before deciding which kind of concrete level to create.
                    Position.Add(new Position { ID = rdr.GetInt32(0), level = rdr.GetString(1) + start = rdr.GetDateTime(3) + end = rdr.GetDateTime(4) });
                }

            catch (MySqlException e)
            {
                Console.WriteLine("Error connecting to database: " + e);
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }

            return Position;
        }


        //For 2.2 step  in RAP App
        public static List<Publication> LoadAll()
        {
            List<Publication> staff = new List<>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("doi,title, authors,year,type,cite_as,available", conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    //Note that inthis RAP assignment you will need to inspect the *type* of the
                    //staff/researcher before deciding which kind of concrete level to create.
                    Position.Add(new Publication { doi = rdr.GetInt32(0), title = rdr.GetString(1) + authors = rdr.GetString(2) + year = rdr.GetInt32(3) + cite_as = rdr.GetString(4) + available = rdr.GetDatetime(5) });
                }

            catch (MySqlException e)
            {
                Console.WriteLine("Error connecting to database: " + e);
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }

            return Publication;
        }


        public static List<Researcher> LoadAll()
        {
            List<Researcher> Researcher = new List<>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("id, type, give_nname, family_name,title,unit,campus,email,photo,degree,supervisor_id,level,utas_start,current_start ", conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    //Note that inthis RAP assignment you will need to inspect the *type* of the
                    //staff/researcher before deciding which kind of concrete level to create.
                    Researcher.Add(new Researcher { ID = rdr.GetInt32(0), GivenName = rdr.GetString(1) + familyname = rdr.GetString(3) + title = rdr.GetString(4) + unit = GetString(5),
                    Campus = GetString(6) });
                }

            catch (MySqlException e)
            {
                Console.WriteLine("Error connecting to database: " + e);
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }

            return Researcher;
        }

          
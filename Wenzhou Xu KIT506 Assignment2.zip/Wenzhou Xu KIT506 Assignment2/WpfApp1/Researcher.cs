﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP_App
{
    class Researcher
    {
        public Researchewr()
        {
            Position = databaseAdapter.LoadAll();

            //Part of step 2.3.2 in Week 9 tutorial
            foreach (Position e in staff)
            {
                e.Skills = databaseAdapter.LoaddatabaseAdapter(e.ID);
             //For step 1.1 in Week 9 tutorial
                public List<Researcher Filter(Position position)
        {
            var selected = from Positon e in staff
                           where e.Position == position
                           select e;
            return new List<Position>(selected);
        }
                public void Display()
                {
                    Position.ForEach(Console.WriteLine);
                    
                public Researcher()
                {
                   Publication = databaseAdapter.LoadAll();

                    //Part of step 2.3.2 in Week 9 tutorial
                    foreach (Position e in staff)
                    {
                        e.Skills = databaseAdapter.LoaddatabaseAdapter(e.ID);

                        public List<Researcher Filter(Publication publication)
                        {
                         var selected = from Publication e in Publication
                         where e.Publication == publication
                         select e;
                    return new List<Publication>(selected);
                    }
                 
                   
                    public void Display()
                   {
                    Position.ForEach(Console.WriteLine);
                    } 
       
                    private int id;
        public String GivenName { get; set; }
        public String FamilyName { get; set; }
        public String Title { get; set; }
        public String School { get; set; }
        public String Campus { get; set; }
        public String Email { get; set; }
        public Uri Photo { get; set; }

        public Position GetCurrentJob()
        {
            return null;
        }
        public String CurrentJobTitle()
        {
            return null;
        }
        public DateTime CurrentJobStart()
        {
            return DateTime.Now;
        }
        public Position GetEarliestJob()
        {
            return null;
        }
        public DateTime EarliestStart()
        {
            return DateTime.Now;
        }
        public float Tenure()
        {
            return 0;
        }
        public int PublicationsCount()
        {
            return 0;
        }
    }
}
 //Step 2.3.4 in Week 9 tutorial
        public int RecentTraining()
{
    if ( != null)
    {
        int endYear = DateTime.Today.Year;
        int startYear = endYear - 1; //window is up to 2 years in length
        var allRecent = from TrainingSession skill in Skills
                        where skill.Year >= startYear && skill.Year <= endYear
                        select skill;
        return allRecent.Count();
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP_App
{
    class Student : Researcher
    {
        List<Student> student;
        public List<Student> Workers { get { return student; } set { } }
        public Student : Researcher()
        {
            student= databaseAdapter.LoadAll();

            //Part of step 2.3.2 in Week 9 tutorial
            foreach (e student e in databaseAdapter)
            {
                e.Skills = databaseAdapter(e.ID);
            }
        }

        private object databaseAdapter(object iD)
        {
            throw new NotImplementedException();
        }
    }

    //For step 1.1 in Week 9 tutorial
    public List< Student> Filter(Student Given name Family name )
    {
        var selected = from Student e in student
                       where e.Given name== Given name
                       where e.Family name == Family name
                       where e.== Given name
                       where e.Family name == Family name
                       select e;

        return new List<Student>(selected);


        public void Display()
        {
           student.ForEach(Console.WriteLine);
        private int id;

    public String Degree { get; set; }
    }

    public Student Use(int id)
{
    foreach (Student e in student)
    {
        if (e.ID == id)
        {
            return e;
        }
    }
    return null;
    //FYI, if you have an interest in lambda expressions the above could be achieved with:
    //return staff.First(e => e.ID == id);
}

/// <summary>
/// Removes the Employee with the given ID from the staff list; if a
/// matching Employee was found it is returned, otherwise returns null.
/// </summary>
public Student Fire(int id)
{
    Student target = Use(id);
    if (target != null)
    {
        student.Remove(target);
    }
    return target;
}

    }
}
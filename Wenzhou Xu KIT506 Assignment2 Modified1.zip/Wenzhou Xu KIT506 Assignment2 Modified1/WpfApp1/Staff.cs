﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP_App
{
    class Staff : Researcher
    {

        List<Staff> staff;
        public List<Staff> Workers { get { return staff; } set { } }

        public Researcher()
        {
            staff = databaseAdapter.LoadAll();

            //Part of step 2.3.2 in Week 9 tutorial
            foreach (e in staff,student )
            {
                e.Skills = databaseAdapter(e.ID);
            }
        }

        private object databaseAdapter(object iD)
        {
            throw new NotImplementedException();
        }
    }

    //For step 1.1 in Week 9 tutorial
    public List<Staff > Filter(Publication publication Position position)
    {
        var selected = from Staff e in staff
                       where e.Publication == publication
                       where e.Position == position
                       select e;

        return new List<Staff>(selected);


        public void Display()
        {
            staff.ForEach(Console.WriteLine);
        private int id;

    public float ThreeYearAverage { get; set; }
        public float Performance { get; set; }
    }
}


    public Staff e Use(int id)
{
    foreach (Staff e in staff)
    {
        if (e.ID == id)
        {
            return e;
        }
    }
    return null;
    //FYI, if you have an interest in lambda expressions the above could be achieved with:
    //return staff.First(e => e.ID == id);
}

/// <summary>
/// Removes the Staff with the given ID from the staff list; if a
/// matching Staff was found it is returned, otherwise returns null.
/// </summary>
public Staff null (int id)
{
    Staff target = Use(id);
    if (target != null)
    {
        staff.Remove(target);
    }
    return target;
}

    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP_App
{
    class Position
    {
        public EmploymentLevel level { get; set; }
        public DateTime start
        {
            get; set;
        }
        public DateTime end { get; set; }

        /**Method of Position
         * Return the title of the Position
         **/
         public String Title()
        {
            return null;
        }

         /**student is student
         * A       is Postdoc
         * B       is Lecturer
         * C       is Senior Lecturer
         * D       is Associate Professor
         * E       is Professor
         **/
        public String ToTitle(EmploymentLevel level)
        {
            return null;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP_App
{
   public enum EmploymentLevel
    {
        Student,
        A,
        B,
        C,
        D,
        E
    }

    public enum OutputType
    {
        Conference,
        Journal,
        Other
    }
}

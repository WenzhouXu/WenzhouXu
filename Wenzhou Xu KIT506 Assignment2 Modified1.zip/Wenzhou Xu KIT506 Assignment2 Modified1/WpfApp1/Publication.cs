﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP_App
{
    class Publication
    {
        public String DOI { get; set;}
        public String Title { get; set; }
        public String Authors { get; set; }
        public DateTime Year { get; set; }
        public OutputType Type { get; set; }
        public String CiteAs { get; set; }
        public DateTime Available { get; set; }
        
        public int Age()
        {
            return 0;
        }
    }
}
